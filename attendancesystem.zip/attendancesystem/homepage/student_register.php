<?php 
include('connection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Monitoring System </title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- stylesheet for bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/styles.css"> <!-- stylesheet for log in -->
</head>
<body>

<div class="container" style="max-width: 1000px;">
    <center>
  <br>
  <br><br><br><br><br>
</center>
  <br>

  <div class="lineBorder" style="margin-top: -90px;">
<?php 
if(isset($_POST["register"])) // Create isset. This function returns true if the variable exists.
                              // Make sure that the variable inside isset is same at submit button
{ // Inside isset, you will define your variables, queries, and some validation.


$last_name = $_POST['last_name'];
$first_name = $_POST['first_name'];
$address = $_POST['address'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$birthdate = $_POST['birthdate'];  
$password = $_POST['password'];
// $hashed_password = password_hash($password, PASSWORD_DEFAULT); // to create random string and to avoid sql injection



$query = mysqli_query($conn, "SELECT * FROM tbl_student_credentials WHERE email='$email'");

$query_insert = mysqli_query($conn, "INSERT INTO tbl_student_credentials VALUES('', '$last_name', '$first_name', '$address', '$email', '$gender', '$birthdate', '$password')");   
    if(mysqli_num_rows($query)> 0){
        echo '<div class="alert alert-danger alertClass">
                <center>
                <strong>This email is already taken.</strong>
                </center>
                </div> ';
            }
    
    else{
        if($query_insert) {
             echo '<div class="alert alert-success alertClass">
                <center>
                <strong>Insert Success.</strong>
                </center>
                </div> ';
            }
    }    
}
?>

    <br>    
        <div class="row">
            <div class="col-lg-6">
                <img src="assets/img/undraw_teaching_f1cm.png" class="loginDesign">
            </div>
                <div class="col-lg-6">
                <form action="" method="post">
                    <h4 class="mb-4">Sign Up</h4>
                    <div class="form-group">
                        <input type="text" name="last_name" placeholder="Enter your last name" class="form-control form-control-sm" required>
                        
                        <input type="text" name="first_name" placeholder="Enter your first name" class="form-control mt-2 form-control-sm" required>
                        
                        <input type="text" name="address" placeholder="Enter your address" class="form-control mt-2  form-control-sm" required>

                        <input type="text" name="email" placeholder="Enter your email" class="form-control mt-2 form-control-sm" style="" id="email" required>

                       <span id="availability" style="font-size: 14px;" class="text-primary ml-2">Email available</span> 

                        <select name="gender" class="form-control mt-2 form-control-sm">
                            <option selected disabled>Choose your gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>

                        <input type="date" name="birthdate" placeholder="Enter your birthdate" class="form-control mt-2 form-control-sm" style="" required>
                        
                        
                        

                        <input type="password" name="password" id="password" placeholder="Enter your password" class="form-control mt-2 form-control-sm" maxlength="15" required>

                        <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" class="form-control mt-2 form-control-sm" maxlength="15" required>

                        <span id='message'></span>


                        <!-- <span style="font-size: 14px;" class="text-primary ml-2">Max of 15 characters</span> -->


                    </div>
                    <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px;">
                        
                            <input type="submit" class="btn btn-block btn-primary buttonClass register" value="REGISTER" name="register" id="register">
                    </div>
                    <center>
                       <a href="index.php" class="text-center" style="margin-top: 14px !important;">Back to Homepage.</a>
                    </center>
                </form>
            </div>
        </div>
        <br>
    </div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script>
    /* Validate email */
    $(document).ready(function(){
        $('#email').keyup(function(){
            var email = $(this).val();
            $.ajax({
                url:"username_taken.php",
                method:"POST",
                data:{email:email},
                dataType:"text",
                success:function(html)
                {
                    $('#availability').html(html);
                }
                
            });
        });
    });

$(".alertClass").fadeTo(2000, 500).slideUp(500, function(){
    $(".alertClass").slideUp(500);
});

// Confirm if password matching.



$('#register').attr('disabled', true); // this function disables register button
//since #register is same as id="register" mentioned above register button


$('#password, #confirm_password').on('keyup', function () { // if the password matches

  if ($('#password').val() == $('#confirm_password').val()) {
    $('#message').html('Matching').css('color', 'green'); // the text will display 'Matching'
     $('#register').prop('disabled', false); // and it will enable button
     
  } 
  else {
    $('#message').html('Not Matching').css('color', 'red'); // else, the text will display 'Not Matching'
     $('#register').prop('disabled', true); // and will disable register button.
   } 
});






</script>