<?php 
include('connection.php');
if(isset($_POST['email'])){
	$count = 0;
	$email = $_POST['email'];
	$query = mysqli_query($conn, "SELECT * FROM tbl_student_credentials WHERE email='$email'");

	if(mysqli_num_rows($query) > 0){
		echo '<span class="text-danger">Email already taken</span>';
	}
	else{
		echo '<span class="text-success">Email available</span>';
	}

}

?>