<?php 
          

  $conn = mysqli_connect("localhost", "root", "", "gradingsystem_db");

?>