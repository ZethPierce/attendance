-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2023 at 04:10 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gradingsystem_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '$2y$10$lvBXIolFQqmeHJzhjo06BOsa5UiUtE42w78ziu9tdhghlR/Ynswzu'),
(2, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(3, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(4, 'lastica', 'mark', 'aldrin', 'users', 'user'),
(5, 'newonly', 'newonly', 'newonly', 'newonly', '$2y$10$wn3pCl3.VPv7l8MKsx5gxe/EyKIdNYQxGciZiP4ezyLGpzTQG5yUa'),
(6, 'pogi', 'miguelfranz', '321e', '321e', '$2y$10$hALq9R0y0kCairlanN3xv.cNpkiyBWaY.9CEGzzY7yBz2ii5sIBKa'),
(7, 'b1322', 'b132', 'b132', 'b132', '$2y$10$XBB5l.kcy/yrjH1Y/jWr1.LS8hJP.4WLtbn/hKmxS2iJWAkmdfDH.'),
(8, '321313', '321313', '321313', '321313', '321313');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_announcement`
--

CREATE TABLE `tbl_announcement` (
  `id` int(200) NOT NULL,
  `title` longtext NOT NULL,
  `announcement` longtext NOT NULL,
  `post_date` varchar(200) NOT NULL,
  `post_time` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_announcement`
--

INSERT INTO `tbl_announcement` (`id`, `title`, `announcement`, `post_date`, `post_time`) VALUES
(1, '', 'new', '123', '123'),
(2, '32', '32', 'May 04, 2023', '03:31:08'),
(3, '123', '123', 'May 04, 2023', '03:31:45'),
(4, 'news', 'news', 'May 04, 2023', '03:34:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE `tbl_attendance` (
  `id` int(50) NOT NULL,
  `employee_no` int(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `time_in` varchar(200) NOT NULL,
  `time_out` varchar(200) NOT NULL,
  `date_attendance` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`id`, `employee_no`, `password`, `time_in`, `time_out`, `date_attendance`, `status`) VALUES
(1, 2204444, '123', '10:00:43', '10:00:46', 'May 05, 2023', 'Late'),
(2, 2204444, '123', '10:01:03', '', 'May 05, 2023', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance_set`
--

CREATE TABLE `tbl_attendance_set` (
  `id` int(50) NOT NULL,
  `employee_no` int(255) NOT NULL,
  `time_in` varchar(200) NOT NULL,
  `time_out` varchar(200) NOT NULL,
  `date_attendance` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_attendance_set`
--

INSERT INTO `tbl_attendance_set` (`id`, `employee_no`, `time_in`, `time_out`, `date_attendance`, `status`) VALUES
(3, 2204444, '10:02', '11:00', 'May 05, 2023', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_credentials`
--

CREATE TABLE `tbl_student_credentials` (
  `id` int(11) NOT NULL,
  `student_id` int(255) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `username` varchar(155) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student_credentials`
--

INSERT INTO `tbl_student_credentials` (`id`, `student_id`, `last_name`, `first_name`, `address`, `email`, `gender`, `birthdate`, `username`, `password`) VALUES
(10, 0, 'pogi', 'miguelfranz', '123', 'ramonespiritu32185@gmail.com', 'Male', '2023-05-06', '123', '123'),
(12, 0, 'f321', 'f321f3', '21f321', 'ramonespiritu32185@gmail.com', 'Female', '2023-05-15', 'f321f', '321f321f3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher_credentials`
--

CREATE TABLE `tbl_teacher_credentials` (
  `id` int(11) NOT NULL,
  `employee_no` int(255) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_teacher_credentials`
--

INSERT INTO `tbl_teacher_credentials` (`id`, `employee_no`, `last_name`, `first_name`, `address`, `email`, `gender`, `birthdate`, `username`, `password`) VALUES
(5, 0, 'pogi', 'miguelfranz123', 'metro manila', 'ramonespiritu32185@gmail.com', 'Male', '', 'test', '123'),
(6, 0, 'pogi', 'miguelfranz', 'metro man424ila', 'ramonespiritu32185@gmail.com', 'Male', '123', '1231', '123'),
(7, 0, 'pogi', 'miguelfranz', 'metro manig321gla', 'ramonespiritu32185@gmail.com', 'Female', 'g321g', '321g', 'g321g3'),
(8, 0, 'pogi', 'miguelfranz', 'metro manila', 'ramonespiritu32185@gmail.com', 'Female', '321t3', '12t31t3', '12t3'),
(10, 2204444, 'Lastica', 'Mark Aldrin', 'metro manila', 'ramonespiritu32185@gmail.com', 'Male', '2023-05-03', '123', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_attendance_set`
--
ALTER TABLE `tbl_attendance_set`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_student_credentials`
--
ALTER TABLE `tbl_student_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_teacher_credentials`
--
ALTER TABLE `tbl_teacher_credentials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_attendance_set`
--
ALTER TABLE `tbl_attendance_set`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_student_credentials`
--
ALTER TABLE `tbl_student_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_teacher_credentials`
--
ALTER TABLE `tbl_teacher_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
