<?php

include('connection.php');
session_start();
$username_session = $_SESSION['username']; //getting information of the user
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Attendance Monitoring System</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="../css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
/*          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);*/
        }
        .short-div {
          height:25px;
        }


</style>
<body style="background: #f9f9f9;">
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('teacher_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('../header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>
                <h1>Dashboard</h1><br>
                <div class="row">
                  <div class="col-lg-6">          
                         <?php 
                         $current_date = date('M-d-Y');
                         $res = mysqli_query($conn, 
                           "SELECT tbl_attendance.* 
                            FROM tbl_attendance 
                            JOIN tbl_teacher_credentials 
                            ON tbl_attendance.employee_no = tbl_teacher_credentials.employee_no 
                            WHERE tbl_teacher_credentials.username = '$username_session' 
                            AND tbl_attendance.date_attendance = '$current_date'");
                          
                           ?>         
                                     <div class="card mb-3">
                                         <div class="card-body">
                                            <label style="margin-bottom: 15px;">Time Record</label>
                                                <div style="margin-left: 15px;">
                                                       <?php  
                                                       if(mysqli_num_rows($res) > 0){
                                                       while($row = mysqli_fetch_array($res)){ ?> 
                                                           <div class="row">    
                                                               <div class="col-lg-6">
                                                                    <h6 class="card-title">Punch In Date and Time</h6>
                                                                     <h5 class="card-title"><?php echo $row["time_in"]; ?></h5>
                                                                     <h6 class="card-title"><?php echo $row["date_attendance"]; ?></h6>
                                                               </div>
                                                               <div class="col-lg-6">
                                                                    <h6 class="card-title">Punch Out Date and Time</h6>
                                                                     <h5 class="card-title"><?php echo $row["time_out"]; ?></h5>
                                                                     <h6 class="card-title"><?php echo $row["date_attendance"]; ?></h6>
                                                                </div>
                                                               
                                                           </div>            
                                                       <?php } 
                                             } else {
                                                 echo "You don't have any schedule for today.";
                                             }
                                             ?>
                                            </div>
                                     </div>   
                                </div>
                            </div>
                  <div class="col-lg-6" >
                      <?php 
                      $current_date = date('M-d-Y');
                      $res2 = mysqli_query($conn, 
                        "SELECT tbl_attendance_set.* 
                         FROM tbl_attendance_set 
                         JOIN tbl_teacher_credentials 
                         ON tbl_attendance_set.employee_no = tbl_teacher_credentials.employee_no 
                         WHERE tbl_teacher_credentials.username = '$username_session' 
                         AND tbl_attendance_set.date_attendance = '$current_date'");
                       
                        ?>       <div class="card mb-3">
                                         <div class="card-body">
                                            <label style="margin-bottom: 15px;">My Schedule</label>
                                                <div style="margin-left: 15px;">
                                                       <?php  
                                                       if(mysqli_num_rows($res2) > 0){
                                                       while($row = mysqli_fetch_array($res2)){ ?> 
                                                           <div class="row">    
                                                               <div class="col-lg-6">
                                                                    <h6 class="card-title">Punch In Date and Time</h6>
                                                                     <h5 class="card-title"><?php echo $row["time_in"]; ?></h5>
                                                                     <h6 class="card-title"><?php echo $row["date_attendance"]; ?></h6>
                                                               </div>
                                                               <div class="col-lg-6">
                                                                    <h6 class="card-title">Punch Out Date and Time</h6>
                                                                     <h5 class="card-title"><?php echo $row["time_out"]; ?></h5>
                                                                     <h6 class="card-title"><?php echo $row["date_attendance"]; ?></h6>
                                                               </div>   
                                                           </div>            
                                                       <?php } 
                                             } else {
                                                 echo "You don't have any schedule for today.";
                                             }
                                             ?>
                                            </div>
                                     </div>   
                                </div>
                  </div>
              </div>

                  <div class="col-lg-12" >
                    <label style="margin-bottom: 15px;">Announcement</label>
                        <?php 
                           $res = mysqli_query($conn, "SELECT * FROM tbl_announcement order by ID desc");
                           if($res){
                             $rowcount = mysqli_num_rows($res);
                           }
                       ?>   

                       <?php while($row = mysqli_fetch_array($res)){ ?>

                       <div class="card mb-3" > <!-- border-dark -->
                         <div class="card-header" >Title: <?php echo $row["title"]; ?></div>
                         <div class="card-body text-dark">
                           <h5 class="card-title">Dark card title</h5>
                           <p class="card-text"><?php echo $row["announcement"]; ?></p>
                         </div>
                       </div>
                   <?php } ?>
                  </div>
                   
                     






                </div>


              

        
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="../js/scripts.js"></script>
</body>
</html>


