<?php 
require_once "../controlleruserdata.php"; 
include('connection.php'); // Always include this to create connection to database
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Monitoring System</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- stylesheet for bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/styles.css"> <!-- stylesheet for log in -->
</head>
<body>
<?php 
if(isset($_POST["login"]))
{
// Define Variables for Both Form
$count = 0;    
$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

// Define Query
$res = mysqli_query($conn, "SELECT username FROM tbl_teacher_credentials WHERE username='$username' && password='$password' ");

$count = mysqli_num_rows($res);    
    if($count == 0) { 
    // If $count did not validate any value from database, it displays echo print which is the alert danger. 

    echo '<div class="alert alert-danger alertClass">
                <center>
                    <strong>Invalid</strong> username Or Password.
                </center>
           </div> ';
    }
    else { 
        // else, it will redirect to sample page view or the student dashboard view.
            $_SESSION['username'] = $username;
            header("Location: teacher_dashboard.php");
        }
}
?>

<div class="container" style="max-width: 800px; margin-top: 200px;">
  <div class="lineBorder"> <!-- Class for Line border -->
    <br>    
        <div class="row">
            <div class="col-lg-6">
                <img src="assets/img/undraw_teacher_35j2.png" class="loginDesign">
            </div>
                <div class="col-lg-6" style="margin-top: 40px;">
                <form action="" method="post">
                    <h4 style="font-weight: 400;">Login as Teacher</h4>
                    <div class="form-group-sm">
                        <input type="text" name="username" placeholder="Enter your username" class="form-control mt-3 form-control-sm" required value="<?php echo $username ?>">
                        <input type="password" name="password" placeholder="Enter your password" class="form-control form-control-sm mt-2" required>
                    </div>
                    <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px;">
                        <span><input type="submit" class="btn btn-block btn-primary" value="login" name="login"></span>
                    </div>
                    <!-- <div class="text-center">
                        <a href="student_register.php">No account? Click this to sign up.</a>
                    </div> -->
                    <!-- There's no registration here because it's on teacher side and confidential -->

                </form>
            </div>
        </div>
        <br>
    </div>
</div>
</body>
</html>
