<?php
include('connection.php');
session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Attendance Monitoring System</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }


</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('admin_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid">
                <br>
                <h3>Schedules</h3>
                      <br>
                       <?php 
                          $res = mysqli_query($conn, "SELECT * FROM tbl_attendance_set order by ID desc");
                          if($res){
                            $rowcount = mysqli_num_rows($res);
                          }
                          
                          ?>    
                        <input type="text" id="searchUser" onkeyup="searchBar()" class="form-control" placeholder="Search by schedule">
                          <br>  
                          <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addAdmin">Add New Schedules</button>            
                          <br><br>
                  
                          <table class='table table-bordered table-striped' id="tableUser">
                            <tr style="background: #d9d9d9 !important; text-align: center;">
                              <th>ID</th>
                              <th>Employee Number</th>
                              <th>Time In</th>
                              <th>Time Out</th>
                              <th>Date</th>
                              <!-- <th>Status</th> -->
                              <th>Edit</th> 
                              <th>Delete</th>                                                               
                            </tr>
                          <?php while($row = mysqli_fetch_array($res)){ ?>
                            <tr>
                              <td><?php echo $row["id"]; ?> </td>
                              <td><?php echo $row["employee_no"]; ?></td>
                              <td><?php echo $row["time_in"]; ?></td>
                              <td><?php echo $row["time_out"]; ?></td>
                              <td><?php echo $row["date_attendance"]; ?></td> 
                              <!-- <td><?php echo $row["status"]; ?></td>           -->
                            <td><?php echo '<button class="btn btn-warning editBtnAdmin" data-toggle="modal" data-target="#editBtnAdmin">Edit</button>' ?> </td> 
                              <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
                            </tr>
                            <?php
                            }
                            ?>
                          </table>
                    
                </div>
                <div id="addAdmin" class="modal fade fontStyle" role="dialog" style="zoom: 90%;">
                  <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <form action="" method="post">  
                              <div class="modal-header">
                                <h4 class="modal-title">Add New Schedules</h4>
                              </div>     
                          <div class="modal-body">
                            <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date("F d, Y");?>" name="post_date"/>
                            <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date('h:i:s');?>" name="post_time"/>

                            <?php
                              $query = "SELECT employee_no FROM tbl_teacher_credentials";
                              // Execute the query and retrieve the results
                              $result = mysqli_query($conn, $query);

                            ?>
                              <label for="usr">Employee Number:</label>
                              <select class="form-control" name="employee_no">
                                  <option value="" selected disabled>Choose your employee number...</option>
                                  <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                      <option value="<?php echo $row["employee_no"]; ?>"><?php echo $row["employee_no"]; ?></option>
                                  <?php }  ?>
                              </select>
                              <br>

                              <div class="form-group">
                                <label for="usr">Time In:</label>
                                <input type="time" name="time_in" class="form-control" required>
                              </div>


                              <div class="form-group">
                                <label for="usr">Time Out:</label>
                                <input type="time" name="time_out" class="form-control" required>
                              </div>

                              <div class="form-group">
                                <label for="usr">Date:</label>
                                <input type="text" readonly name="date_attendance" class="form-control" required value="<?php date_default_timezone_set('Asia/Manila'); echo date("F d, Y");?>">
                              </div>



                             
                            </div>
                            <div class="modal-footer">
                              <button type="submit" name="addData" class="btn btn-primary">Add Schedule</button>
                              <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
                            </div>
                          </form>
                    </div>
                  </div>
                </div>   



                <!-- Update Modal -->
                <div id="editBtnAdmin" class="modal fade" role="">
                  <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                      <form action="" method="post">
                      <div class="modal-header">
                        <h4 class="modal-title">Update Schedule</h4>
                      </div>     
                      <div class="modal-body">      
                        <input id="update_admin_id" name="update_admin_id" type="hidden">
                          <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date("F d, Y");?>" name="post_date"/>
                          <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date('h:i:s');?>" name="post_time"/>
                          <?php
                            $query = "SELECT employee_no FROM tbl_teacher_credentials";
                            // Execute the query and retrieve the results
                            $result = mysqli_query($conn, $query);

                          ?>
                          <div class="form-group">
                               <label for="usr">Employee Number</label>
                              <select class="form-control" name="employee_no" id="employee_no">
                                  <option value="" selected disabled>Choose your employee number...</option>
                                  <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                      <option value="<?php echo $row["employee_no"]; ?>"><?php echo $row["employee_no"]; ?></option>
                                  <?php }  ?>
                              </select>
                          </div>    
                          <div class="form-group">
                              <label for="usr">Time In</label>
                              <input type="text" name="time_in" id="time_in" class="form-control">
                          </div>
                          <div class="form-group">
                              <label for="usr">Time Out</label>
                              <input type="text" name="time_out" id="time_out" class="form-control">
                          </div> 
                          <div class="form-group">
                              <label for="usr">Date</label>
                              <input type="text" name="date_attendance" id="date_attendance" class="form-control">
                          </div> 
                        </div>

                        <div class="modal-footer">
                          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
                          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
                        </div>
                      </form>
                    </div>
                  </div>
                </div>     
                <!-- End of Update Modal -->


                <!-- Delete Modal -->
                <div id="deleteAdmin" class="modal fade fontStyle" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Delete Announcement</h4>
                        </div>
                      <form action="" method="post">
                        <div class="modal-body">
                          <input id="delete_id" name="delete_id" type="hidden">
                          <p>Are you sure you want to delete this Announcement?</p>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" name="deleteData" class="btn btn-danger">Delete</button>
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </form>
                    </div>  
                  </div>
                </div>
                <?php
                      // Check if the success message is set in the session and display it
                      if (isset($_SESSION['success'])) {
                          echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
                          unset($_SESSION['success']); // Clear the success message from the session
                      }
                      else if (isset($_SESSION['danger'])) {
                          echo '<div class="alert alert-danger">' . $_SESSION['danger'] . '</div>';
                          unset($_SESSION['danger']); // Clear the success message from the session
                      }

                      ?>
        <!-- ADD QUERY [ADD NEW USER] -->  
        <?php 
          if(isset($_POST["addData"]))
             {
                $employee_no = $_POST['employee_no'];
                $time_in = $_POST['time_in'];
                $time_out = $_POST['time_out'];
                $date_attendance = $_POST['date_attendance'];
                $status = NULL;
                $query_show = mysqli_query($conn, "SELECT * FROM tbl_attendance_set");
                      //else, i-eexecute nya yung insert query
                      $query_insert = mysqli_query($conn, "INSERT INTO tbl_attendance_set 
                          VALUES('', '$employee_no', '$time_in', '$time_out', '$date_attendance', '$status')");
                        if($query_insert)
                        {            
                          $_SESSION['success'] = 'Data Inserted'; // Set the success message in the session
                          echo '<script> window.location="admin_schedules.php";</script>';                        
                    }
                  
              }

             if(isset($_POST['deleteData'])){    
                $id = $_POST['delete_id'];
                $query = mysqli_query($conn, "DELETE FROM tbl_attendance_set WHERE id='$id'");
                if($query) {
                 $_SESSION['success'] = 'Successfully Deleted'; // Set the success message in the session
                 echo '<script> window.location="admin_schedules.php";</script>';                  
                }
             }
        ?>  




        <!-- UPDATE QUERY [EDIT ADMIN USER] -->                 
        <?php 
             if(isset($_POST['updateData'])){    
                $employee_no = $_POST['employee_no'];
                $time_in = $_POST['time_in'];
                $time_out = $_POST['time_out'];
                $date_attendance = $_POST['date_attendance'];
                $query = mysqli_query($conn, "UPDATE tbl_attendance_set 
                  SET 
                  employee_no='$employee_no', 
                  time_in='$time_in', 
                  time_out='$time_out',
                  date_attendance='$date_attendance'
'                  WHERE id='$id'");
              if ($query) {
                    $_SESSION['success'] = 'Successfully Updated'; // Set the success message in the session
                    echo '<script> window.location="admin_schedules.php";</script>';
                 }
             }
        ?>

     







    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>


<script>
    $(document).ready(function(){
        $('.deleteAdmin').on('click', function(){
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
            }).get();
            $('#delete_id').val(data[0]);          
        });
    });




 $(document).ready(function(){
        $('.deleteUser').on('click', function(){
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_ids').val(data[0]);          
        });
    });



$(document).ready(function(){
    $('.editBtnAdmin').on('click', function(){      
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();

            $('#update_admin_id').val(data[0]);
            $('#employee_no').val(data[1]);
            $('#time_in').val(data[2]);
            $('#time_out').val(data[3]);
            $('#date_attendance').val(data[4]);
    });
 });




$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});



 var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };


$('input[type="file"]'). change(function(e){
    fileName = e. target. files[0]. name;
    $('#imgLabel').text(fileName);
    $('#imgPreview').attr('src','images/'+fileName);
});



function searchBar() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("searchUser");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableUser");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}



</script>
<script>
   // Get all the alerts with the "auto-close" class
  var alerts = document.querySelectorAll('.alert');

  // Loop through the alerts and set a timeout function to remove them after 4 seconds
  alerts.forEach(function(alert) {
    setTimeout(function() {
      alert.remove();
    }, 4000);
  });
</script>