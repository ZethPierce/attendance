<?php 
session_start();
unset($_SESSION["username"]);
?>
<script>
	window.location="homepage/index.php";
</script>