<?php 
include('connection.php'); // Always include this create connection to database
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Monitoring System</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- stylesheet for bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/styles.css"> <!-- stylesheet for log in -->
</head>
<body>
<?php 
if(isset($_POST["login"]))
{
// Define Variables for Both Form
$count = 0;    
$email = $_POST['email'];  
$password = $_POST['password'];  

// Define Query
$res = mysqli_query($conn, "SELECT email FROM tbl_student_credentials WHERE email='$email' && password='$password' ");

$count = mysqli_num_rows($res);    
    if($count == 0) { 
    // If $count did not validate any value from database, it displays echo print which is the alert danger. 

    echo '<div class="alert alert-danger alertClass">
			    <center>
			    	<strong>Invalid</strong> Email Or Password.
			    </center>
		   </div> ';
    }
    else { 
    	// else, it will redirect to sample page view or the student dashboard view.

            header("Location: student_portal.php");
        }
}
?>

<div class="container" style="max-width: 800px; margin-top: 200px;">
  <div class="lineBorder"> <!-- Class for Line border -->
    <br>    
        <div class="row">
            <div class="col-lg-6">
                <img src="assets/img/undraw_exams_g4ow.png" class="loginDesign">
            </div>
                <div class="col-lg-6" style="margin-top: 40px;">
                <form action="" method="post">
                    <h4 style="font-weight: 400;">Login as Student</h4>
                    <div class="form-group-sm">
                        <input type="text" name="email" placeholder="Enter your email" class="form-control mt-3 form-control-sm" required>
                        <input type="password" name="password" placeholder="Enter your password" class="form-control form-control-sm mt-2" required>
                    </div>
                    <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px;">
                        <span><input type="submit" class="btn btn-block btn-primary" value="LOGIN" name="login"></span>
                    </div>
                    <div class="text-center">
                        <a href="student_register.php">No account? Click this to sign up.</a>
                    </div>
                </form>
            </div>
        </div>
        <br>
    </div>
</div>
</body>
</html>
