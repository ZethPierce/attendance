<?php

echo "<h1>Sample Page</h1>";

?>