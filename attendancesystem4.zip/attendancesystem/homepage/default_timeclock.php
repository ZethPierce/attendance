<?php 
require_once "../controlleruserdata.php"; 
include('connection.php'); // Always include this to create connection to database
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Monitoring System</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- stylesheet for bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/styles.css"> <!-- stylesheet for log in -->
</head>
<style>
    .color-hov {
        background: #7975fe; 
        border-color: #7975fe;
    }
    .color-hov:hover {
        background: #504ce1;
        border-color: #504ce1;
    }
</style>
<body>
<?php 
if(isset($_POST["login"]))
{
// Define Variables for Both Form
$count = 0;    
$username = $_POST['username'];  
$password = $_POST['password'];  

// Define Query
$res = mysqli_query($conn, "SELECT username FROM tbl_teacher_credentials WHERE username='$username' && password='$password' ");

$count = mysqli_num_rows($res);    
    if($count == 0) { 
    // If $count did not validate any value from database, it displays echo print which is the alert danger. 

    echo '<div class="alert alert-danger alertClass">
                <center>
                    <strong>Invalid</strong> username Or Password.
                </center>
           </div> ';
    }
    else { 
        // else, it will redirect to sample page view or the student dashboard view.

            header("Location: teacher_portal.php");
        }
}
?>

<div class="container" style="max-width: 800px; margin-top: 100px;">
    <a href="index.php"><button class="btn btn-primary color-hov">Back</button></a>
    <br><br>
  <div class="lineBorder"> <!-- Class for Line border -->
    <br>    
     <?php
                  // Check if the success message is set in the session and display it
                  if (isset($_SESSION['success'])) {
                      echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
                      unset($_SESSION['success']); // Clear the success message from the session
                  }
                  else if (isset($_SESSION['danger'])) {
                      echo '<div class="alert alert-danger">' . $_SESSION['danger'] . '</div>';
                      unset($_SESSION['danger']); // Clear the success message from the session
                  }

                  ?>
        <div class="row">
           
            <div class="col-lg-6">
                <img src="../img/clock.png" class="loginDesign img-fluid" >
            </div>
                <div class="col-lg-6" style="margin-top: 50px;">
                    <?php include ('../time.php'); ?>
                <form action="" method="post">

                    <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date('h:i:s');?>" name="time_in"/>

                    <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date('h:i:s');?>" name="time_out"/>

                    <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date("F d, Y");?>" name="date_attendance"/>

                    <div class="form-group-sm">
                        <input type="text" name="employee_no" style="height: 40px; font-size: 15px;" placeholder="Employee No." class="form-control mt-3 form-control-sm"  required>
                        <input type="password" name="password" style="height: 40px; font-size: 15px;" placeholder="Password" class="form-control form-control-sm mt-2" required>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px;">
                                <span><input type="submit" class="btn btn-block btn-primary color-hov" value="IN" name="timeIn"></span>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px;">
                                <span><input type="submit" class="btn btn-block btn-primary color-hov" value="OUT" name="timeOut"></span>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="text-center">
                        <a href="student_register.php">No account? Click this to sign up.</a>
                    </div> -->
                    <!-- There's no registration here because it's on teacher side and confidential -->

                </form>
            </div>
        </div>
        <br>
    </div>
</div>
<?php
if(isset($_POST["timeIn"]) || isset($_POST["timeOut"]))
{
    $employee_no = $_POST['employee_no'];
    $password = $_POST['password'];
    $date_attendance = $_POST['date_attendance'];
    $status = "Present";
    $query_schedule = mysqli_query($conn, "SELECT * FROM tbl_attendance_set WHERE employee_no = '$employee_no'");
    $schedule_row = mysqli_fetch_assoc($query_schedule);
    
    
    $start_workday = $schedule_row['time_in']; // Set the start time of the workday
    $time_in = $_POST['time_in'];
    $status = "Present"; // Default status is "Present"

    // Compare the time_in value with the start of the workday
    if ($time_in > $start_workday) {
      $status = "Late";
    }
    $count = 0;
    $query_show = mysqli_query($conn, "SELECT * FROM tbl_teacher_credentials");
    $res = mysqli_query($conn, "SELECT employee_no FROM tbl_teacher_credentials WHERE employee_no='$employee_no' && password='$password' ");
    $count = mysqli_num_rows($res);

    if($count == 0) { 
        $_SESSION['danger'] = 'Invalid Username or Password';
        echo '<script> window.location="timeclock.php";</script>';     
    }
    else {
        $query_select = mysqli_query($conn, "SELECT * FROM tbl_attendance WHERE employee_no='$employee_no' && date_attendance='$date_attendance' && time_out=''");
        $count_select = mysqli_num_rows($query_select);
        
        if(isset($_POST["timeIn"])) {
            if($count_select > 0) {
                $_SESSION['danger'] = "You've already clocked in."; 
                echo '<script> window.location="timeclock.php";</script>';
            }
            else {
                $time_in = $_POST['time_in'];
                $query_insert = mysqli_query($conn, "INSERT INTO tbl_attendance 
                    VALUES('', '$employee_no', '$password', '$time_in', '', '$date_attendance', '$status')");
                if($query_insert)
                {            
                    $_SESSION['success'] = "You've been logged in successfully.";
                    echo '<script> window.location="timeclock.php";</script>';                        
                }
            }
        }
        else if(isset($_POST["timeOut"])) {
            if($count_select == 0) {
                $_SESSION['danger'] = "You haven't clocked in yet."; 
                echo '<script> window.location="timeclock.php";</script>';
            }
            else {
                $time_out = $_POST['time_out'];
                $query_update = mysqli_query($conn, "UPDATE tbl_attendance SET time_out='$time_out' WHERE employee_no='$employee_no' && date_attendance='$date_attendance' && time_out=''");
                if($query_update)
                {            
                    $_SESSION['success'] = "You've been logged out successfully.";
                    echo '<script> window.location="timeclock.php";</script>';                        
                }
            }
        }
    }
}
?>

</body>
</html>
