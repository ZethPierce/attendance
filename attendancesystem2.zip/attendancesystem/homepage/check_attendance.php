<?php
	$current_time = date('H:i:s');
	$query = "SELECT * FROM tbl_attendance_set WHERE time_out <= '$current_time' AND status <> 'ABSENT'";
	$result = mysqli_query($conn, $query);

	if (mysqli_num_rows($result) > 0) {
	  while ($row = mysqli_fetch_assoc($result)) {
	    $id = $row['id'];
	    $query = "UPDATE tbl_attendance SET status = 'ABSENT' WHERE id = $id";
	    mysqli_query($conn, $query);
	  }
	}


?>